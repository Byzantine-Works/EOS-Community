import React from 'react';

const AccountCreate = () => {
    return(<div>Hi</div>);
}

export default AccountCreate;