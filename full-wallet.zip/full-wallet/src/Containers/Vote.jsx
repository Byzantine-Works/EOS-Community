import React from 'react';


const Vote = () => {
    return(<div>Hi</div>);
}

export default Vote;