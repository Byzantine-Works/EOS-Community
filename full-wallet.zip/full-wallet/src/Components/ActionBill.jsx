import React from 'react';


const ActionBill = props => {

    return (
        <div className="ActionBillContainer">
   
        </div>
    )

}

export default ActionBill;
