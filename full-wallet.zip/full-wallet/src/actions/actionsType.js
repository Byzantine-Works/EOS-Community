export const UPDATE_STATE = 'UPDATE_STATE';
export const LOAD_ABI = 'LOAD_ABI';
export const LOAD_WASM = 'LOAD_WASM';
